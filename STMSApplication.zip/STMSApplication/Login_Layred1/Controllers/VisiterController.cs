﻿using DomainLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Login_Layred1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VisiterController : ControllerBase
    {
        private readonly IVisiter _course;
        public VisiterController(IVisiter course)
        {
            this._course = course;
        }

        //GetAllCourse
        [HttpGet("getAllVisiters")]
        public IActionResult GetAllCourses()
        {
            var response = this._course.GetAllCourses();
            return Ok(response);
        }

        //GetSingleRecord
        [HttpGet("get/{id:int}")]
        public IActionResult GetSingleRecord(long id)
        {
            return Ok(this._course.GetSingleCourse(id));
        }

        //AddCourse
        [HttpPost("AddVisiters")]
        public IActionResult AddCourse(Visiter course)
        {
            return Ok(this._course.AddCourse(course));
        }

        //RemoveCourse
        [HttpDelete("DeleteVisiters")]
        public IActionResult RemoveCourse(int id)
        {
            return Ok(this._course.RemoveCourse(id));
        }

        //UpdateCourse
        [HttpPut("UpdateVisiters")]
        public IActionResult UpdateCourse(Visiter course)
        {
            return Ok(this._course.UpdateCourse(course));
        }
    }
}
